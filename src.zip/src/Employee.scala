/**
  *
  * @author macbook
  */
class Employee(var empId: String, var name: String, var salPerDay: String, var salary: Double) {
  def getEmpId: String = empId

  def setEmpId(empId: String): Unit = {
    this.empId = empId
  }

  def getName: String = name

  def setName(name: String): Unit = {
    this.name = name
  }

  def getSalPerDay: String = salPerDay

  def setSalPerDay(salPerDay: String): Unit = {
    this.salPerDay = salPerDay
  }

  def getSalary: Double = salary

  def setSalary(salary: Double): Unit = {
    this.salary = salary
  }
}